import SwiftUI

public struct interfaceView: View { // App Interface
    @Environment(\.userPreferences) var customValues
    public init() {}
    @State private var opacityWiggle = false
    
    public var body: some View {
        ZStack{  
            if customValues.weather {
                Image(uiImage: #imageLiteral(resourceName: "Map.png")) //map
                    .resizable()
                    .frame(width: 300, height: 612)
                    .offset(y: 40)
            } else {
                Image(uiImage: #imageLiteral(resourceName: "Map.png")) //map
                    .resizable()
                    .frame(width: 300, height: 612)
            }
            
            
            
            ZStack{ //User location
                if customValues.weather {
                    if customValues.locationPin {
                        Circle()
                            .fill(Color(#colorLiteral(red: 0.0, green: 0.3813630939, blue: 0.9982447028, alpha: 1.0)))
                            .frame(width: 15, height: 15)
                            .offset(x: 0, y: -125)
                        Circle()
                            .stroke(Color.white, lineWidth: 3)
                            .frame(width: 15, height: 15)
                            .offset(x: 0, y: -125)
                    } else {
                        Spacer()
                    }
                } else {
                    if customValues.locationPin {
                        Circle()
                            .fill(Color(#colorLiteral(red: 0.0, green: 0.3813630939, blue: 0.9982447028, alpha: 1.0)))
                            .frame(width: 15, height: 15)
                            .offset(x: 0, y: -165)
                        Circle()
                            .stroke(Color.white, lineWidth: 3)
                            .frame(width: 15, height: 15)
                            .offset(x: 0, y: -165)
                    } else {
                        Spacer()
                    }
                }
            } .shadow(color: Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.1)), radius: 4, y: 4)
            
            
            ZStack{ //car model
                Rectangle()
                    .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                    .frame(width: 267, height: 52)
                    .cornerRadius(12)
                    .shadow(color: Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.1)), radius: 4, y: 4)
                HStack{
                    Spacer()
                        .frame(width: 30)
                    Text("Tesla S")
                        .font(.system(size: 12, weight: .regular, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                    Text(self.customValues.licenseNumber)
                        .font(.system(size: 12, weight: .bold, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                    Spacer()
                    ZStack{
                        Image(uiImage: #imageLiteral(resourceName: "Car.png"))
                            .resizable()
                            .frame(width: 130, height: 84)
                            .offset(y: -8)
                        Image(uiImage: #imageLiteral(resourceName: "CarLights.png"))
                            .resizable()
                            .frame(width: 130, height: 84)
                            .offset(y: -8)
                            .animation(nil)
                            .opacity(opacityWiggle ? 1 : 0)
                            .animation(Animation.easeInOut(duration: 1).delay(2).repeatForever(autoreverses: true))
                            .onAppear(){
                                opacityWiggle.toggle()
                            }
                    }.offset(x: -15)
                }
            }.offset(y: -5)
            
            VStack{ //UI
                navigationBar()
                Group{
                    if customValues.weather {
                        Image(uiImage: #imageLiteral(resourceName: "Weather.png"))
                            .resizable()
                            .frame(width: 267, height: 65)
                            .shadow(color: Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.1)), radius: 4, y: 4)
                    } else {
                    }
                    
                }
                Spacer()
                modalView()
            } 
            .frame(width: 287, height: 612)
            .cornerRadius(25)
        }
    }
}
