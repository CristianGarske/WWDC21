import SwiftUI

public struct modalView: View{
    @Environment(\.userPreferences) var customValues
    public init (){}
    public var body: some View{
        ZStack{ //modal
            Rectangle()
                .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                .frame(width: 287, height: 273)
            
            VStack(spacing: 10){
                Spacer().frame(height: 5)
                
                HStack{ //Hour/Price
                    Text("Today, 5:48 PM")
                        .font(.system(size: 13, weight: .semibold, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                    Spacer()
                    Text("US$21.44")
                        .font(.system(size: 13, weight: .semibold, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: -0.09660359472036362, green: 0.4546257257461548, blue: 0.9992086291313171, alpha: 1.0)))
                }
                
                Rectangle().fill(Color(#colorLiteral(red: 0.8407003283500671, green: 0.8407003283500671, blue: 0.8407003283500671, alpha: 1.0))).frame(height: 1)
                
                
                HStack{ //Destination
                    Image(uiImage: #imageLiteral(resourceName: "Arrow.png"))
                        .resizable()
                        .frame(width: 11, height: 40)
                    VStack(alignment: .leading){
                        Text("Infinite Loop 1, CA 95014")
                            .font(.system(size: 12, weight: .medium, design: .default))
                            .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                        Spacer()
                            .frame(height:8)
                        Text("Apple Park, CA 95014")
                            .font(.system(size: 12, weight: .bold, design: .default))
                            .foregroundColor(Color(#colorLiteral(red: -0.09660359472036362, green: 0.4546257257461548, blue: 0.9992086291313171, alpha: 1.0)))
                    }
                    Spacer()
                    Group{
                        if customValues.trafficWarning {
                            HStack{
                                Rectangle().fill(Color(#colorLiteral(red: 0.8407003283500671, green: 0.8407003283500671, blue: 0.8407003283500671, alpha: 1.0))).frame(width: 1, height: 50)
                                Spacer()
                                    .frame(width:10)
                                VStack{
                                    ZStack{
                                        Circle()
                                            .stroke(Color(#colorLiteral(red: 1.0, green: 0.1491314173, blue: 0.0, alpha: 1.0)), lineWidth: 2)
                                            .frame(width: 25, height: 25, alignment: .center)
                                        Image(systemName: "car.2")
                                            .font(.system(size: 11, weight: .bold))
                                            .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                                    } .offset(y: 3)
                                    Text("Slowdown")
                                        .font(.system(size: 10, weight: .semibold, design: .default))
                                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                                    Text("7-min delay")
                                        .font(.system(size: 7, weight: .semibold, design: .default))
                                        .foregroundColor(Color(#colorLiteral(red: 0.26514732837677, green: 0.26514732837677, blue: 0.26514732837677, alpha: 1.0)))
                                }
                            }
                        } else {
                            VStack{
                                Text("Traffic slow")
                                    .font(.system(size: 10, weight: .semibold, design: .default))
                                    .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                                Text("7-min delay")
                                    .font(.system(size: 7, weight: .semibold, design: .default))
                                    .foregroundColor(Color(#colorLiteral(red: 0.26514732837677, green: 0.26514732837677, blue: 0.26514732837677, alpha: 1.0)))
                            }
                        }
                    }
                }
                
                
                Rectangle().fill(Color(#colorLiteral(red: 0.8407003283500671, green: 0.8407003283500671, blue: 0.8407003283500671, alpha: 1.0))).frame(height: 1)
                
                HStack{ //Driver
                    Image(uiImage: #imageLiteral(resourceName: "Driver.png"))
                        .resizable()
                        .frame(width: 40, height: 40)
                    VStack(alignment: .leading){
                        Text("Melyssa H.")
                            .font(.system(size: 13, weight: .semibold, design: .default))
                            .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                        Spacer()
                            .frame(height:2)
                        HStack(alignment: VerticalAlignment.top, spacing: 0){
                            Image(systemName: "star.fill")
                                .font(.system(size:8, weight: .regular))
                                .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                            Image(systemName: "star.fill")
                                .font(.system(size:8, weight: .regular))
                                .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                            Image(systemName: "star.fill")
                                .font(.system(size:8, weight: .regular))
                                .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                            Image(systemName: "star.fill")
                                .font(.system(size:8, weight: .regular))
                                .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                            Image(systemName: "star.leadinghalf.fill")
                                .font(.system(size:8, weight: .regular))
                                .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                        }.frame(height: 15)
                        
                    }
                    Spacer()
                    ZStack{
                        ZStack{
                            ZStack(alignment: .topLeading){
                                Rectangle()
                                    .fill(Color(#colorLiteral(red: 0.9031170010566711, green: 0.918201208114624, blue: 0.9392618536949158, alpha: 1.0)))
                                    .frame(width: 10, height: 10)
                                Rectangle()
                                    .fill(Color(#colorLiteral(red: 0.9031170010566711, green: 0.918201208114624, blue: 0.9392618536949158, alpha: 1.0)))
                                    .cornerRadius(10)
                            }.frame(width: 90, height: 25)
                            
                            Text("I have arrived.")
                                .font(.system(size: 10, weight: .medium, design: .default))
                                .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.3813630939, blue: 0.9982447028, alpha: 1.0)))
                                .frame(width: 100, height: 20)
                        } .offset(x: -40, y: -10)
                        
                        ZStack{
                            if customValues.smartReply {
                                ZStack(alignment: .topTrailing){
                                    Rectangle()
                                        .fill(Color(#colorLiteral(red: 0.2948952317237854, green: 0.5523220896720886, blue: 0.9995197653770447, alpha: 1.0)))
                                        .frame(width: 10, height: 10)
                                    Rectangle()
                                        .fill(LinearGradient(
                                                gradient: .init(colors: [Color(#colorLiteral(red: 0.0, green: 0.3813630939, blue: 0.9982447028, alpha: 1.0)), Color(#colorLiteral(red: 0.4550631046, green: 0.6557807326, blue: 0.9979295135, alpha: 1.0))]),
                                                startPoint: .init(x: 0, y: 0.5),
                                                endPoint: .init(x: 1.5, y: 0.5)))
                                        .cornerRadius(10)
                                }.frame(width: 90, height: 25)
                                
                                Text("I'm coming.")
                                    .font(.system(size: 12, weight: .medium, design: .default))
                                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
                                    .frame(width: 100, height: 35)
                            } else {
                                Spacer()
                                    .frame(width: 90, height: 25)
                            }
                            
                        } .offset(y: 12)
                    } .frame(height: 45)
                }

                
                Rectangle().fill(Color(#colorLiteral(red: 0.8407003283500671, green: 0.8407003283500671, blue: 0.8407003283500671, alpha: 1.0))).frame(height: 1)
                
                
                HStack{ //Buttons
                    ZStack{ //Button Cancel
                        if customValues.cancelButton {
                            Rectangle()
                                .fill(Color(#colorLiteral(red: 0.9031170010566711, green: 0.918201208114624, blue: 0.9392618536949158, alpha: 1.0)))
                                .frame(height: 45)
                                .cornerRadius(12)
                            Text("CANCEL")
                                .font(.system(size: 12, weight: .bold, design: .default))
                                .foregroundColor(Color(#colorLiteral(red: 0.8894588351, green: 0.1420151591, blue: 0.0, alpha: 1.0)))
                        } else {
                        }
                        
                    }
                    ZStack { //Button Safety
                        if customValues.safetyButton {
                            Rectangle()
                                .fill(Color(#colorLiteral(red: 0.9031170010566711, green: 0.918201208114624, blue: 0.9392618536949158, alpha: 1.0)))
                                .frame(height: 45)
                                .cornerRadius(12)
                            HStack{
                                Image(systemName: "shield.lefthalf.fill")
                                    .font(.system(size: 14, weight: .bold))
                                    .foregroundColor(Color(#colorLiteral(red: -0.09660359472036362, green: 0.4546257257461548, blue: 0.9992086291313171, alpha: 1.0)))
                                Text("SAFETY")
                                    .font(.system(size: 12, weight: .bold, design: .default))
                                    .foregroundColor(Color(#colorLiteral(red: -0.09660359472036362, green: 0.4546257257461548, blue: 0.9992086291313171, alpha: 1.0)))
                                    .offset(x: -5)
                            }
                        } else {
                        }
                    }
                } 
                Spacer()
                
            } .frame(width: 267, height: 273)
            
            VStack{ //Home Indicator
                Spacer()
                Image(uiImage: #imageLiteral(resourceName: "HomeIndicator.png"))
                    .resizable()
                    .frame(width:267, height: 30)
            }
        } .frame(width: 267, height: 273)
    }
}
