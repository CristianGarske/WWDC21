import SwiftUI

private struct UserPreferencesKey: EnvironmentKey {
    static var defaultValue: UserPreferences = UserPreferences()
}

extension EnvironmentValues {
    public var userPreferences: UserPreferences {
        get { self[UserPreferencesKey.self] }
        set { self[UserPreferencesKey.self] = newValue }
    }
}

public struct UserPreferences {
    public let navigationTitle: String
    public let licenseNumber: String
    public let backButton: Bool
    public let locationPin: Bool
    public let cancelButton: Bool
    public let trafficWarning: Bool
    public let shareRide: String
    public let weather: Bool
    public let smartReply: Bool
    public let safetyButton: Bool
    
    public init(
        navigationTitle: String = "Car",
        licenseNumber: String = "",
        backButton: Bool = false,
        locationPin: Bool = false,
        cancelButton: Bool = false,
        trafficWarning: Bool = false,
        shareRide: String = "arrowshape.turn.up.right.fill",
        weather: Bool = true,
        smartReply: Bool = false,
        safetyButton: Bool = false
        
    ){
        self.navigationTitle = navigationTitle
        self.licenseNumber = licenseNumber
        self.backButton = backButton
        self.locationPin = locationPin
        self.cancelButton = cancelButton
        self.trafficWarning = trafficWarning
        self.shareRide = shareRide
        self.weather = weather
        self.smartReply = smartReply
        self.safetyButton = safetyButton
    }
}
