import SwiftUI

public struct experienceArea: View{ //Experience Area
    @Environment(\.userPreferences) var customValues
    public init() {}
    public var body: some View {
        ZStack{ //1
            if customValues.locationPin {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Text("1")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
            
        } .offset(x: 200, y: -105)
        
        ZStack{ //2
            if customValues.navigationTitle == "Car"{
                Image(uiImage: #imageLiteral(resourceName: "DialogVert.png"))
                    .resizable()
                    .frame(width: 50, height: 55)
                Text("2")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogVertGood.png"))
                    .resizable()
                    .frame(width: 50, height: 55)
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
        } .offset(x: 0, y: -355)
        
        ZStack{ //3
            if customValues.backButton {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                    .rotationEffect(.degrees(-180))
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                    .rotationEffect(.degrees(-180))
                Text("3")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
            
        } .offset(x: -200, y: -250)
        
        ZStack{ //4
            if customValues.shareRide == "square.and.arrow.up" {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Text("4")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
            
        } .offset(x: 200, y: -250)
        
        ZStack{ //5
            if customValues.cancelButton {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                    .rotationEffect(.degrees(-180))
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                    .rotationEffect(.degrees(-180))
                Text("5")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
            
        } .offset(x: -200, y: 245)
        
        ZStack{ //6
            if customValues.licenseNumber == ""{
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                    .rotationEffect(.degrees(-180))
                Text("6")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                    .rotationEffect(.degrees(-180))
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
            
        } .offset(x: -200, y: 0)
        
        ZStack{ //7
            if customValues.smartReply {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Text("7")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
        } .offset(x: 200, y: 180)
        
        ZStack{ //8
            if customValues.weather {
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                    .rotationEffect(.degrees(-180))
                Text("8")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                    .rotationEffect(.degrees(-180))
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
            
        } .offset(x: -200, y: -200)
        
        
        
        ZStack{ //9
            if customValues.trafficWarning {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Text("9")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
        } .offset(x: 200, y: 110)
        
        
        
        ZStack{ //10
            if customValues.safetyButton {
                Image(uiImage: #imageLiteral(resourceName: "DialogSideGood.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Image(systemName: "checkmark")
                    .frame(width: 40, height: 20)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            } else {
                Image(uiImage: #imageLiteral(resourceName: "DialogSide.png"))
                    .resizable()
                    .frame(width: 65, height: 35)
                Text("10")
                    .font(.system(size: 15, weight: .bold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)))
            }
            
        } .offset(x: 200, y: 245)
    } 
}
