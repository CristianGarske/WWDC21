
import SwiftUI

let gradientStart = Color(#colorLiteral(red: 0.9562498927116394, green: 0.9562721848487854, blue: 0.9562601447105408, alpha: 1.0))
let gradientEnd = Color(#colorLiteral(red: 0.9562498927116394, green: 0.9562721848487854, blue: 0.9562601447105408, alpha: 1.0))

public struct contentView: View{
    @Environment(\.userPreferences) var customValues
    public init() {}
    public var body: some View{
        
        ZStack{
            Rectangle() //background
                .fill(LinearGradient(gradient: Gradient(colors: [gradientStart, gradientEnd]), startPoint: .top, endPoint: .bottom))
                .scaledToFill()
            
            VStack{ //content
                Spacer()
                ZStack{ //iPhone
                    Rectangle()  //background 
                        .frame(width: 281, height: 606)
                    interfaceView() //interface
                        .frame(width: 281, height: 606)
                    Image(uiImage: #imageLiteral(resourceName: "iPhone12_frame.png")) //frame
                        .resizable()
                        .frame(width: 320, height: 642.78)
                }
                Spacer()
            }
            experienceArea() //Heuristics
        }
    }
}
