import SwiftUI

public struct navigationBar: View{
    @Environment(\.userPreferences) var customValues
    public init (){}
    public var body: some View{
        ZStack{ //navigation bar
            Rectangle()
                .fill(Color(#colorLiteral(red: 0.981221616268158, green: 0.9814146161079407, blue: 0.9812150597572327, alpha: 1.0)))
                .frame(width: 287, height: 70)
                .shadow(color: Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.1)), radius: 4, y: 4)
            VStack{
                Image(uiImage: #imageLiteral(resourceName: "Status Bar.png")) // Status Bar
                    .resizable()
                    .frame(width:290, height: 30)
                HStack{
                    Group{
                        if customValues.backButton {
                            Image(systemName: "chevron.left")
                                .frame(width: 40, height: 20)
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                        } else {
                            Spacer()
                                .frame(width: 40)
                        }
                    }
                    Spacer()
                    Text(self.customValues.navigationTitle)
                        .font(.system(size: 13, weight: .semibold, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                    Spacer()
                    Image(systemName: self.customValues.shareRide)
                        .frame(width: 40, height: 20)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                }
            }
        }
    }
}

